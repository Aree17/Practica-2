package com.unl.sing.base.controller;

import java.io.BufferedReader;
import java.io.FileReader;

public class almacenamiento {
    private int[] numeros;
    private int[] numerosRepetidos;
    private int lineaActual;
    private int contadorRepetidos;
    private int contador;

    public void almacenarNumeroArray() {
        try {
            String archivo = "/home/arelys/Descargas/data.txt";
            BufferedReader contadorTotal = new BufferedReader(new FileReader(archivo));
            int totalNumeros = 0;
            while (contadorTotal.readLine() != null) {
                totalNumeros++;
            }
            contadorTotal.close();

            numeros = new int[totalNumeros];
            numerosRepetidos = new int[totalNumeros];

            BufferedReader lector = new BufferedReader(new FileReader(archivo));
            String linea;
            int i = 0, m = 0;
            while ((linea = lector.readLine()) != null) {
                lineaActual = Integer.parseInt(linea.trim());
                if (esRepetidoArray(numeros, lineaActual)) {
                    numerosRepetidos[m++] = lineaActual;
                    contadorRepetidos++;
                } else {
                    numeros[i++] = lineaActual;
                    contador++;
                }
            }
            lector.close();
        } catch (Exception e) {
            System.out.println("Error al abrir el archivo: " + e);
        }
    }

    public boolean esRepetidoArray(int[] numeros, int lineaActual) {
        for (int i = 0; i < numeros.length; i++) {
            if (numeros[i] == lineaActual) {
                return true;
            }
        }
        return false;
    }

    public void printArray() {
        for (int i = 0; i < contador; i++) {
            System.out.println(numeros[i]);
        }
    }

    public void printRepetidos() {
        for (int i = 0; i < contadorRepetidos; i++) {
            System.out.println(numerosRepetidos[i]);
        }
    }

    public static void main(String[] args) {
        almacenamiento a = new almacenamiento();
        a.almacenarNumeroArray();
        System.out.println("No repetidos:");
        a.printArray();
        System.out.println("Repetidos:");
        a.printRepetidos();
        System.out.println("Se registraron "+ a.contadorRepetidos+ " Numeros repetidos");
        System.out.println("Se registraron "+ a.contador+ " Numeros sin repetir");


        Long tiempoInicio=System.nanoTime();
        Long tiempoFinal = System.nanoTime();
        Long tiempoTotal= tiempoFinal-tiempoInicio;
        System.out.println("el tiempo de ejecucion es:" + tiempoTotal + " nanosegundos");

    }
}
